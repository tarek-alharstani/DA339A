/*
  Author: Tarek Alharstani
  Id: AO8587
  Study program: DT
*/
package partyController;

import partyView.*;
import partyModel.*;

import javax.swing.*;


public class Controller {
    MainFrame view; // the main association to the GUI from the controller-class, GUI classes are in package partyView
    GuestManager register;  //class GuestManager is in package partyModel

    private static int guestsTotal;

    //constructor called from MainProgram
    public Controller(int maxNbrOfGuests) {
        guestsTotal = maxNbrOfGuests;

        //Creates a GuestManager-object referenced by the instance variable register
        register = new GuestManager(maxNbrOfGuests);

        // Create main GUI-object referenced by the instance variable view
        view = new MainFrame(this); // give the GUI a reference to the Controller-object by using this to send a reference to the Controller-object

        //Update the GUI with information from the guest list (even if it might be empty)
        view.updateGuestList(register.getInfoStrings());

        //Set some values in the fields to the left in the GUI
        setDefaultValuesInView();
    }

    /* This method is called from the GUI-classes when a button is pressed.
       The parameter is an Enum (look at Enum ButtonType in package partyView)
       that is used to keep track of types of buttons between
       the GUI-classes and the controller.
     */
    public void buttonPressed(ButtonType button){
        int index; //variable used in two switch cases below
        switch (button) {
            case Add:
                /* Below are some code to get the information from the fields to the
                   left in the GUI "Guest Information" and display that in the prompt for show.
                   You can delete this example code later.
                */
                System.out.println("First name: "+view.getFirstNameText());
                System.out.println("Last name: "+view.getLastNameText());
                System.out.println("Street: "+view.getStreetText());
                System.out.println("Zip code: "+view.getZipCodeText());
                System.out.println("City: "+view.getCityText());

                Object item = view.getCountriesItem(); //get the item chosen in the drop-down list of countries, the program handles this as just an Object-object
                Countries country = (Countries) item; //make it a Countries object - we know that this is supposed to be that, this type of type conversion can be risky
                System.out.println("Country: "+country.toString());
                // example code end here


                if(register.getNbrOfGuests() < guestsTotal){
                    register.addGuest(view.getFirstNameText(), view.getLastNameText(), view.getStreetText(), view.getZipCodeText(), view.getCityText(), country);
                }// Om gästlistan är full: Visa en dialogruta som frågar om användaren vill utöka gästlistan
                else{
                    int x = JOptionPane.showConfirmDialog(null, "The guest list is full! Do you want to extend the list?");
                    if(x == JOptionPane.YES_OPTION){
                        guestsTotal +=10; // Öka antalet totala gäster med 10
                        // Lägg till en ny gäst i registret med information från visningsobjektet (view)
                        register.addGuest(view.getFirstNameText(), view.getLastNameText(), view.getStreetText(), view.getZipCodeText(), view.getCityText(), country);
                    }
                }
                break;

            case Change:
                index = view.getListIndex(); //get the chosen index from the list of guest information from the GUI
                if(validateIndex(index)){ //validateIndex is a private method in this class
                    Guest guestToChange = register.getGuestAt(index); //get what is hopefully the matching Guest-object to the one chosen one in the GUI
                    if(guestToChange != null){


                         // Hämta gästens nuvarande adressobjekt
                        Address guestToChangeAds = guestToChange.getAddress();
                        // Uppdatera gästens information med värden från GUI:et
                        Object itemY = view.getCountriesItem();
                        Countries countryY = (Countries) itemY;
                        register.getGuestAt(index).setFirstName(view.getFirstNameText());
                        register.getGuestAt(index).setLastName(view.getLastNameText());
                        guestToChangeAds.setStreet(view.getStreetText());
                        guestToChangeAds.setZipCode(view.getZipCodeText());
                        guestToChangeAds.setCity(view.getCityText());
                        guestToChangeAds.setCountry(countryY);
                        register.getGuestAt(index).setAddress(guestToChangeAds);
                        // Meddela användaren om att ingen matchning hittades i listan att ändra
                    } else {
                        JOptionPane.showMessageDialog(null, "Didnt find match in list to change");
                    }
                }
                break;

            case Delete:
                // Hämta index från GUI

                index = view.getListIndex();
                // Skriv ut indexet till konsolen (kan tas bort senare)

                System.out.println("When pressed delete we got index: "+index); //Can be removed later
                // testa index

                if (validateIndex(index)) {
                    // Om indexet är giltigt, ta bort gästen från registret

                    register.deleteGuest(index);
                }
                break;
        }


        // Hämta det aktuella antalet gäster från registret
        int attendance = register.getNbrOfGuests();
        // Uppdatera antalet gäster i GUI:et genom att använda view.setNumGuest-metoden
        view.setNumGuest(Integer.toString(attendance));
        // Uppdatera gästlistan i GUI:et med informationen från registret
        view.updateGuestList(register.getInfoStrings());
         /*
        uppdaterar antalet gäster som visas i GUI:et
        och uppdaterar gästlistan i GUI:et med den aktuella informationen från registret.
        Det säkerställer att GUI:et speglar korrekt information om gästerna efter förändringar i gästlistan.
         */

    }

    /* This method is called when something is changed,
       such as when the user chooses a guest in the list
       to the right in the GUI-window.
       It should update the fields to the left in the GUI-window
       with information from the selected guest.
     */
    private void updateView(int index) {
        System.out.println("Called updateView in controller with index:"+index); //Can be removed later
        if(validateIndex(index)) {
            Guest guest = new Guest(); //Remove later when line below is used
            //Guest guest = register.getGuestAt(index); //ADD CODE HERE by activating this line to see what happens with a null-object and later when method getGuestAt is implemented in class GuestManager
            if (guest == null) {
                JOptionPane.showMessageDialog(null, "The selection did not match a guest");
                System.out.println("Given index: "+index+ " did not contain a Guest-object");
                setDefaultValuesInView();
            } else {
                /*ADD CODE HERE to set info in GUI.
                  Replace the strings below with a method call to the Guest-object
                  referenced by variable guest that returns the value of
                  the instance variable containing the first name.
                 */
                // Sätt förnamnet från Guest-objektet till GUI

                view.setFirstNameText(register.getGuestAt(index).getFirstName());

                //ADD CODE HERE to do the equivalent for the rest of the information about a guest
                // Sätt efternamnet  och address från Guest-objektet till GUI

                view.setLastNameText(register.getGuestAt(index).getLastName());
                view.setStreetText(register.getGuestAt(index).getstreet());
                view.setZipCodeText(register.getGuestAt(index).getZIP());
                view.setCityText(register.getGuestAt(index).getCity());
                view.setCountriesItem(Countries.Sverige);
            }
        }
    }

    /* Method used to create the drop-down menu of countries
       in the GUI.
     */
    public Countries [] getCountriesItems() {
        return Countries.values ();
    }

    /* This method is called from the GUI when the user changes selection in the
       list to the right in the GUI. It updates the information to the left in the GUI
       to match the selected guest.
     */
    public void guestListIndexChanged(int index) {
        if(validateIndex(index)) {
            updateView(index);
        }
    }

    /* This method is used to check that we have gotten an index
       that is not a negative value from the GUI.
       If no row is chosen in the view to the right in the GUI
       we will get the value -1 and then we show an error message for the user.
     */
    private boolean validateIndex(int index) {
        boolean ok = true;
        if (index < 0) {
            JOptionPane.showMessageDialog(null, "Select an item in the list!");
            ok = false;
        }
        return ok;
    }

    /* This method is used to set some default values in the
       fields to the left in the GUI.
     */
    private void setDefaultValuesInView(){
        view.setFirstNameText("First name");
        view.setLastNameText("Last name");
        view.setStreetText("Street");
        view.setZipCodeText("zip code");
        view.setCityText("City");
        view.setCountriesItem(Countries.Unknown);
    }

}
