package partyController;
import javax.swing.JOptionPane;

public class MainProgram
{
    public static void main(String[] args)
    {
        boolean checked = true;
        String nbrOfGuestsAtTheBeginning;

        while (checked)
        {
            nbrOfGuestsAtTheBeginning = JOptionPane.showInputDialog("\n" +
                    "How many people do you plan to invite?");

            if (!nbrOfGuestsAtTheBeginning.matches("[0-9]+"))
            {
                JOptionPane.showMessageDialog(null, "ERROR: should not contain any symbols or letters");
                checked = true;
            }
            else
            {
                Controller controller = new Controller(Integer.parseInt(nbrOfGuestsAtTheBeginning));
                checked = false;
            }
        }
    }
}
