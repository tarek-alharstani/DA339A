/*
  Author: Tarek Alharstani
  Id: AO8587
  Study program: DT
*/
package partyModel;

public class GuestManager {

  private int nbrOfGuests = 0;
  private Guest[] guestList; // Array för att lagra gästinformation

  // Konstruktor som skapar en array för gästinformation med det maximala antalet gäster

  public GuestManager(int maxNbrOfGuests){
    // Kontrollera att det maximala antalet gäster är giltigt (större än 0)
      if(maxNbrOfGuests > 0){ // om den är större än 0
        // Skapa en ny array av Guest-objekt med längden maxNbrOfGuests
        this.guestList = new Guest[maxNbrOfGuests];
      }
  }

  /* A method that returns the number of guests stored in
     the guest list.
   */
  public int getNbrOfGuests(){
    return nbrOfGuests;
  }
// Returnerar antalet gäster som för närvarande finns i listan

  public void addGuest(String firstName, String lastName, String street, String city, String zipCode, Countries country ){
    Guest newGuest = new Guest(firstName, lastName, street, city, zipCode, country);
    if(nbrOfGuests < guestList.length){
      // Lägger till den nya gästen på nuvarande position i arrayen
      guestList[nbrOfGuests] = newGuest;
      nbrOfGuests++;
    }
    else{
      increaseGuestList(); // Kallar på metoden
      // Add the new guest to the next position in the array
      guestList[nbrOfGuests] = newGuest;
      nbrOfGuests++;
    }
  }


  public void deleteGuest(int index){
    guestList[index] = null;// indikerar att platsen nu är tom och inte längre innehåller en giltig gäst
    //gästen vid detta index har tagits bort.
    moveElementsToLeft(index); // täckar upp det tomma utrymmet efter den borttagna gästen
    nbrOfGuests--;// räknare för att ange det faktum att en gäst har tagits bort.
  }

  private void moveElementsToLeft(int index){

    //// Loopa från det angivna indexet till slutet av arrayen
    for(int i = index; i<guestList.length; i++){
      // // Kontrollera om nästa position (i+1) är inom arrayens gränser
      if(i+1 < guestList.length){
        // Flytta värdet från nästa position till den aktuella positionen
        guestList[i] = guestList[i+1];
      }
    }
    // // Sätt värdet på sista positionen i arrayen till null för att fylla det sista platsen<

    guestList[guestList.length - 1] = null;
  }


  // GÖR LISTAN STÖÖRE SÅ MAN KAN LÄGGA TILL flera gäster
  private void increaseGuestList(){
    // Skapa en ny array som är 10 element större än den nuvarande arrayen
    Guest[] newGuestList = new Guest[guestList.length + 10];
    // Kopiera befintliga element till den nya arrayen
    for(int i = 0; i < guestList.length; i++){
      newGuestList[i] = guestList[i];
    }//// Uppdatera instansvariabeln för att peka på den nya, större arrayen
    guestList = newGuestList;
    // increaseGuestList för att öka kapaciteten för gästlistan och lägger sedan till den nya gästen i registret
  }

  /* A method that returns the Guest-object at the given
     index n the parameter.
   */
  public Guest getGuestAt(int index){
// returnerar en specifik gäst från listan.
    // Kontrollera om det angivna indexet är inom arrayens giltiga område
    if(index >= 0 && index < guestList.length){
      // Returnera "Guest"-objektet vid det angivna indexet
      return guestList[index];
    }
    else{// Returnera null om indexet är ogiltigt
    return null;
  }
  }

  // En metod som skapar en array av strängar som representerar
  // informationen om varje gäst

  public String[] getInfoStrings() {

//// Skapa en array av strängar med storlek nbrOfGuests
    String[] infoStrings = new String[nbrOfGuests];
    for (int i = 0; i < nbrOfGuests; i++) {
      //// Kontrollera om gästplatsen inte är null innan du anropar toString
      if (guestList[i] != null) {
        //// Anropa toString-metoden för varje "Guest"-objekt och lagra resultatet i arrayen
        infoStrings[i] = guestList[i].toString();
        //Skapar en array av strängar som representerar informationen om varje gäst
        // genom att använda deras toString-metoder.
      } else {
        // Om gästplatsen är null, sätt infoStrings till en lämplig värde (t.ex. en tom sträng)
        infoStrings[i] = "";
      }
    }//// Returnera arrayen med gästinformation
    return infoStrings;
  }

}
