/*
  Author: Tarek Alharstani
  Id: AO8587
  Study program: DT
*/
package partyModel;

public class Guest {
    /* Declare instance variables for first name and last name as String-objects and
       address as an Address-object.
     */
    private String  lastName;
    private String firstName;
    private Address address;

    public Guest(){
        this.firstName = "Unknown";
        this.lastName = "Unknown";
        // Skapa en ny Address-instans och tilldela den till variabeln 'address'
        this.address = new Address();
    }

    public String getZIP(){
        return this.address.getZipCode();
    }
    public String getstreet(){
        return this.address.getStreet();
    }
    public String getCity(){
        return this.address.getCity();
    }


    public Guest( String firstName, String lastName, String street, String city, String zipCode, Countries country){
        // Kontrollera om firstName är ogiltig eller saknas

        if(firstName == null || firstName .isEmpty()){//  om det värde som skickats till metoden är ogiltigt eller saknas,
            // Om firstName är null eller en tom sträng, sätts this.firstName till "Unknown
            this.firstName = "Unknown"; //DEFAULT VALUE
        }else{
            // Annars sätt värdet av firstName till det angivna värdet
            this.firstName = firstName;
        }// Kontrollera om lastName är ogiltig eller saknas
        if(lastName == null || lastName .isEmpty()){
            // Om lastName är null eller en tom sträng, sätt this.lastName till "Unknown"

            this.lastName = "Unknown";
        }else{
            // Annars sätt värdet av lastName till det angivna värdet

            this.lastName = lastName;
        } // Skapa en ny Address-instans med hjälp av angiven adressinformation

        this.address = new Address(street, city, zipCode, country);
    }

    public String getFirstName(){
        return firstName;
    }
    // hämta värdet på instansvariabeln firstName

    public void setFirstName(String firstName){//  sätta värdet på instansvariabeln firstName
        if(firstName != null && !firstName.isEmpty()){
            // Om det nya förnamnet passerar dessa tester, sätts det som värdet på firstName
            this.firstName = firstName;
        }else{
            // Annars, sätt värdet på firstName till "Unknown"
            this.firstName = "Unknown";
        }
    }

    public String getLastName(){
        return lastName;
    }

    public void setLastName(String lastName){
        // Validera det nya efternamnet för att se om det är ogiltigt eller saknas

        if(lastName != null && !lastName.isEmpty()){
            //om det värde som skickats till metoden är ogiltigt eller saknas,
            this.lastName = "Unknown";
        }else{
            // Annars, sätt lastName till det angivna värdet
            this.lastName = lastName;
        }
    }

    public Address getAddress(){
        return address;
    }// hämta värdet

    public void setAddress(Address address){// sätta värdet på instansvariabeln address.
        if(address == null){// om det nya adressobjektet är null.
            this.address = new Address();
        }else{
            // Om det nya adressobjektet inte är null, tilldelas det befintliga address.
            this.address = address;
        }
    }

    /* Write a toString method to return a String made of first name and
          family name and the address (by calling the toString method of the Address-object)
          formatted in one line (this will be shown in the window under "Guest Register" ).
        */
    public String toString() {
        return "Guest{" +
                "lastName='" + lastName + '\'' +
                ", firstName='" + firstName + '\'' +
                ", address=" + address +
                '}';
    }
}
