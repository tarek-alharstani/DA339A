/*
  Author: Tarek Alharstani
  Id: AO8587
  Study program: DT
*/
package partyModel;

public class Address{

    private String street, city, zipCode;
    private Countries country;
// representera landet i adressen från enumet Countries

    public Address(){
        //  en konstruktor ny Address-instans och sätter dess attribut till standardvärden
        this.street = "null";
        this.city =   "null";
        this.zipCode = "null";
        this.country = Countries.Unknown;
    }


    public Address(String street, String city, String zipCode, Countries country){
        // konstruktor med parametrar för att sätta adressen med angivna värden.
        if(street == null || street.isEmpty()){
            this.street = null;
            System.out.println("this value isn't really set");
        }else{
            this.street = street;
            System.out.println("(this value is set);");
        }
        if(city == null || city.isEmpty()){
            this.city = null;
            System.out.println("this value isn't really set");
        }else{
            this.city = city;
            System.out.println("(\"this value is set\");");
        }
        if(zipCode == null || zipCode.isEmpty()){
            this.zipCode = null;
            System.out.println("this value isn't really set");
        }else{
            this.zipCode = zipCode;
            System.out.println("(\"this value is set\");");
        }
        if(country == null){
            this.country = Countries.Unknown;
            System.out.println("this value isn't really set");
        }else{
            this.country = country;
            System.out.println("(\"this value is set\");");
        }
    }



    public String getStreet(){
        return this.street;
    }

    public void setStreet(String street){
        // testa det nya gatunamnet för att se om det är ogiltigt eller saknas

        if(street == null || street.isEmpty()){
            // Om det nya gatunamnet är ogiltigt eller saknas, sätt street till "Unknown".

            this.street = "Unknown";
            System.out.println("this value isn't really set.");
        }else{
            // Annars, sätt street till det angivna värdet
            this.street = street;
        }
    }


    public String getZipCode(){
        return this.zipCode;
    }

    public void setZipCode(String zipCode){
        // testar det nya postnumret för att se om det är ogiltigt eller saknas

        if(zipCode == null || zipCode .isEmpty()){
            // Om det nya postnumret är ogiltigt eller saknas, sätt zipCode till "Unknown".

            this.zipCode = "Unknown";
            System.out.println("this value isn't really set");
        }else{
            // Annars, sätt zipCode till det angivna värdet

            this.zipCode = zipCode;
        }
    }

    public String getCity(){
        return this.city;
    }

    public void setCity(String city){
        if(city == null || city.isEmpty()){
            this.city = "Unknown";
            System.out.println("this value isn't really set");
        }else{
            this.city = city;

        }
    }
    public Countries getCountry(){
        return this.country;
    }

    public void setCountry(Countries country){
        // testar det nya landet för att se om det är ogiltigt

        if(country == null){
            // Om det nya landet är ogiltigt, sätt country till Countries.Unknown.

            this.country = Countries.Unknown;
        }else{
            // Annars, sätt country till det angivna landet
            this.country = country;
        }
    }
    //returnerar en strängrepresentation av adressen genom att sammanfoga dess olika attribut.v
    public String toString() {
        return "Address{" +
                "street='" + street + '\'' +
                ", city='" + city + '\'' +
                ", zipCode='" + zipCode + '\'' +
                ", country=" + country +
                '}';
    }
}
