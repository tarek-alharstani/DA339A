package controller;

/**
 * Main klass som skapar ett objekt av klassen Controller.
 * @author Tarek Alharstani/ Mohammed Nasrallah
 * ID: ao8587 / ao8701
 */
public class Main {
    public static void main(String[] args) { Controller theController = new Controller();
    }
}
