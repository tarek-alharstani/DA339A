package controller;

//only imports what is strictly necessary from view-package;

import model.*;
import view.MainFrame;
import view.ButtonType;

import javax.swing.*;
import java.util.ArrayList;

/**
 * Controller är länken mellan Entity klasserna och boundary klasserna.
 * Klassens syfte är att genom användarens input skapa olika ordrar
 * men även att visa de produkter som finns valbara för menyn.
 * Klassen hanterar vad som händer vid användarens olika val i GUI.
 */
public class Controller {
    private MainFrame view;
    private Order currentOrder;
    private ButtonType currentLeftMenu = ButtonType.NoChoice;


    private ArrayList<Pizza> pizzaMenu;
    // Varje objekt i listan representerar en specifik typ av pizza och innehåller information som namn, ingredienser, pris
    private ArrayList<Drinks> drinkMenu;
 // Varje objekt i listan representerar en specifik typ av dryck och innehåller information som namn, typ, pris
    Pizza pizza;
    Drinks drinks;
    OrderManagement orderManagement;

    /**
     * Konstruktor skapar objekt av OrderManagement och Order.
     * Den kallar på de metoder som skapar innehållet för meny av pizza och dryck.
     * Den aktiverar alla knappar i GUI men avaktiverar Add och View Selected Order.
     */
    public Controller() {
        orderManagement = new OrderManagement();
        currentOrder = new Order(0);
        createPizza();
        createDrinks();
        view = new MainFrame(1000, 500, this);
        view.enableAllButtons();
        view.disableAddMenuButton();
        view.disableViewSelectedOrderButton();
    }

    /**
     * Metoden skapar de olika pizzor som finns valbara för användaren i GUI. Pizzorna läggs in i en ArrayList.
     * Metoden använder sig av classen Pizza Toppings
     */
    public void createPizza() {
        pizzaMenu = new ArrayList<>();
        pizza = new Pizza("Pizza pepperoni ", 65, new PizzaToppings[]{PizzaToppings.tomato_sauce, PizzaToppings.mozzarella,PizzaToppings.pepperoni, PizzaToppings.mushrooms});
        pizzaMenu.add(pizza);
        pizza = new Pizza("Pizza Margherita", 60, new PizzaToppings[]{PizzaToppings.tomato_sauce, PizzaToppings.cheese});
        pizzaMenu.add(pizza);
        pizza = new Pizza("Pizza Veggie", 70, new PizzaToppings[]{PizzaToppings.tomato_sauce, PizzaToppings.onion});
        pizzaMenu.add(pizza);
        pizza = new Pizza("Pizza Spicy",75, new PizzaToppings[]{PizzaToppings.tomato_sauce, PizzaToppings.Jalpeno});
        pizzaMenu.add(pizza);
        pizza = new Pizza("FriendsPizza", 85, new PizzaToppings[]{PizzaToppings.tomato_sauce, PizzaToppings.mozzarella, PizzaToppings.cheese,PizzaToppings.pineapple});
        pizzaMenu.add(pizza);

    }

    /**
     * Metoden skapar de drycker som finns valbara för användaren i GUI. Den använder sig av objekt från klasserna
     * Drinks och DrinksAlc.
     * @author Tarek/ Mohammed
     */

    public void createDrinks() {
        drinkMenu = new ArrayList<>();
        //Alcoholic Drinks
        drinkMenu.add(new DrinksAlc("Beer", 55, 3.0));
        drinkMenu.add(new DrinksAlc("Wine", 65, 10.0));

        //Non-Alcoholic Drinks
        drinkMenu.add(new Drinks("Juice", 30));
        drinkMenu.add(new Drinks("Cola", 25));

    }

    /**
     * Metod för att skapa strängar av de olika tillgängliga pizzor.
     * @return sträng med olika pizzor
     */
    private String[] getPizzaStrings() {
        // Skapa en sträng-array med information om pizzorna
        String[] infoStrings = new String[pizzaMenu.size()];
        for (int i = 0; i < infoStrings.length; i++) {
            infoStrings[i] = pizzaMenu.get(i).toString();
        }

        return infoStrings;
    }
    /**
     * Metod för att skapa strängar av de olika tillgängliga drycker.
     * @return returnerar sträng med olika drycker
     */
    private String[] getDrinksStrings() {
        String[] infoStrings = new String[drinkMenu.size()];

        for (int i = 0; i < infoStrings.length; i++) {
            infoStrings[i] = drinkMenu.get(i).toString();
        }
        return infoStrings;
    }
    /**
     * Metod för att skapa strängar orderhistorik med objekt av alla gjorda ordrar.
     * @return returnerar sträng med olika ordrar
     */

    private String[] getOrderHistoryStrings() {
        Order[] orders = orderManagement.getAllOrders();
        String[] infoStrings = new String[orders.length];
        for (int i = 0; i < orders.length; i++) {
            infoStrings[i] = orders[i].toString();
        }
        return infoStrings;
    }


    /**
     * Switchmetod för olika tillgängliga knappar och de scenario som är möjliga via GUI.
     * @param button
     */
    public void buttonPressed(ButtonType button) {

        switch (button) {
            case Add:
                addItemToOrder(view.getSelectionLeftPanel());
                break;

            case Food:
                setToFoodMenu();
                break;

            case Drinks:
                setToDrinkMenu();
                break;

            case Clear:
                clearPanels();
                break;

            case OrderHistory:
                setOrderHistoryMenu();
                break;

            case Order:
                placeOrder(view.getSelectionLeftPanel());
                break;

            case ViewOrder:
                viewSelectedOrder();
                break;
        }
    }

    /**
     * Funktion för att lägga till pizza och dryck i en order genom en switch, aktiveras av knappen "add"
     * Ålderskontroll för att köpa alkohol; kräver att användaren är 18 år eller äldre. Ifall yngre än 18 visas...
     * ett felmeddelande. Uppdaterar prislabel när nya produkter läggs till i ordern och synliggör dem i högra panelen i GUI.
     * @param selectionIndex
     */
    public void addItemToOrder(int selectionIndex) {
        if (selectionIndex != -1) { //  Kontrollera om något är valt i vänstermenyn
            switch (currentLeftMenu) {
                case Food:
                    // Om den vänstra menyn är inställd på Food, lägg till produkten från pizzaMenu i beställningen

                    currentOrder.addProduct(pizzaMenu.get(selectionIndex));
                    break;
                case Drinks:
                    // Om den vänstra menyn är inställd på Drinks

                    if (drinkMenu.get(selectionIndex) instanceof DrinksAlc) {
                        // Om drycken är alkoholhaltig, begär ålder från användaren
                        String input = JOptionPane.showInputDialog("can you state your age Please!");
                        int age = Integer.parseInt(input);
                        // Kontrollera åldern för att se om användaren är gammal nog att köpa alkohol

                        if (age >= 18) {
                            // Om användaren är 18 år eller äldre, lägg till drycken i beställningen
                            currentOrder.addProduct(drinkMenu.get(selectionIndex));

                        } else {
                            // Annars visa meddelande att användaren inte får köpa alkohol
                            JOptionPane.showMessageDialog(null, "You are not allowed to bya this drink");
                        }
                    } else {
                        // Om drycken inte är alkoholhaltig, lägg till den i beställningen

                        currentOrder.addProduct(drinkMenu.get(selectionIndex));
                        break;
                    }
            }
            // Uppdatera högerpanelen med den nya informationen i beställningen
            view.populateRightPanel(currentOrder.getOrdersInfo());
            // Uppdatera etiketten som visar kostnaden för den aktuella beställningen
            view.setTextCostLabelRightPanel("Total cost: " + currentOrder.getPrice()); //set the text to show cost of current order
        }
    }

    /**
     * Metod som presenterar innehållet i den valda ordern i den högra panelen av GUI.
     * Använder orderhantering för att visa sparad orderhistorik.
     */
    public void viewSelectedOrder() {
        // Hämta indexet för den valda posten i vänsterpanelen
        int selectionIndex = view.getSelectionLeftPanel();
        // Återställ kostnadsetiketten till ett standardmeddelande
        view.setTextCostLabelRightPanel("Total cost: Select an order");
        // Kontrollera om något är valt i vänsterpanelen och om den vänstra menyn är inställd på OrderHistory
        if ((selectionIndex != -1) && currentLeftMenu == ButtonType.OrderHistory) {
            // Hämta den valda ordern från OrderHistory
            Order thisOrder = orderManagement.getAllOrders()[selectionIndex];
            // Uppdatera högerpanelen med informationen från den valda ordern
            view.populateRightPanel(thisOrder.getOrdersInfo());
            // Uppdatera kostnadsetiketten för att visa kostnaden för den valda ordern
            view.setTextCostLabelRightPanel("Total cost: " + thisOrder.getPrice()); //set the text to show cost of current order
        }
    }

    /**
     * Metod som visar upp matlistan/pizzalistan när användaren trycker på Food-knappen. Metoden visar även pris i för
     * vald produkt i GUI.
     */
    public void setToFoodMenu()
    {     // Ställ in den aktuella vänstra menyn till Food
        currentLeftMenu = ButtonType.Food;
        // Uppdatera vänsterpanelen med strängar som representerar pizzamenyn
        view.populateLeftPanel(getPizzaStrings());
        // Uppdatera högerpanelen med informationen om den aktuella beställningen
        view.populateRightPanel(currentOrder.getOrdersInfo());
        // Uppdatera kostnadsetiketten för att visa kostnaden för den aktuella beställningen
        view.setTextCostLabelRightPanel("Total cost of order: " + currentOrder.getPrice()); //set the text to show cost of current order
        // Aktivera alla knappar och inaktivera knappen för att visa matmenyn och knappen för att visa vald order
        view.enableAllButtons();
        view.disableFoodMenuButton();
        view.disableViewSelectedOrderButton();
    }

    /**
     * Metod som visar upp dryckeslistan när användaren trycker på Drinks-knappen. Metoden visar även pris i för
     * vald produkt i GUI.
     */
    public void setToDrinkMenu()
    {    // Ställ in den aktuella vänstra menyn till Drinks
        currentLeftMenu = ButtonType.Drinks;
        // Uppdatera vänsterpanelen med strängar som representerar dryckesmenyn
        view.populateLeftPanel(getDrinksStrings());
        // Uppdatera högerpanelen med informationen om den aktuella beställningen
        view.populateRightPanel(currentOrder.getOrdersInfo()); //update left panel with new item - this takes a shortcut in updating the entire information in the panel not just adds to the end
        // Uppdatera kostnadsetiketten för att visa kostnaden för den aktuella beställningen
        view.setTextCostLabelRightPanel("Total cost of order: " + currentOrder.getPrice()); //set the text to show cost of current order
        // Aktivera alla knappar och inaktivera knappen för att visa dryckesmenyn och knappen för att visa vald order
        view.enableAllButtons();
        view.disableDrinksMenuButton();
        view.disableViewSelectedOrderButton();
    }

    /**
     * Metod när användaren väljer Order History skapa en lista av de ordrar som gjorts.
     */
    public void setOrderHistoryMenu()
    {     // Ställ in den aktuella vänstra menyn till Order History
        currentLeftMenu = ButtonType.OrderHistory;
        // Rensa högerpanelen från tidigare innehåll
        view.clearRightPanel();
        // Uppdatera vänsterpanelen med strängar som representerar orderhistoriken
        view.populateLeftPanel(getOrderHistoryStrings());
        // Aktivera alla knappar och inaktivera knapparna för att lägga till i menyn och lägga till i ordern
        view.enableAllButtons();
        view.disableAddMenuButton();
        view.disableOrderButton();
    }

    /**
     * Metod för att tömma höger panelen innan ny order skapas och tömmer den nuvarande ordern.
     */
    public void clearPanels()
    {    // Skapa en ny tom order med en total kostnad på 0
        currentOrder = new Order(0);
        // Rensa högerpanelen från tidigare innehåll
        view.clearRightPanel();
        // Aktivera alla knappar
        view.enableAllButtons();
    }

    /**
     ** Metoden anropas vid skapande av en ny order. Den lägger till den nuvarande ordern från högra panelen
     *  i en lista i OrderManagement för att spara orderhistoriken.
     *  Dessutom uppdaterar den priset och rensar högra panelen genom clearPanels().
     *  Metoden använder en boolean och isPizzaOK-metoden för att kontrollera om beställningen innehåller minst en pizza.
     *  Om det inte finns någon pizza i beställningen visas ett felmeddelande
     * @param selectionIndex
     */
    public void placeOrder(int selectionIndex) {
        if (!currentOrder.isPizzaOK()) {
            JOptionPane.showMessageDialog(null, "You have to buy at least one Pizza.");
            return;
        }

        view.populateRightPanel(currentOrder.getOrdersInfo());
        view.setTextCostLabelRightPanel("TOTAL COST: " + currentOrder.getPrice());
        orderManagement.addOrder(currentOrder);
        clearPanels();
        view.enableAllButtons();
        view.disableAddMenuButton();
        view.disableViewSelectedOrderButton();
    }

}




