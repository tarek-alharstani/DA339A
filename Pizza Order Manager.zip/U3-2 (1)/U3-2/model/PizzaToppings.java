package model;

/**
 * Enum klass som samlar de PizzaToppings som finns möjliga att skapa pizzor av
 * @author Tarek/ Mohammed
 */
public enum PizzaToppings
{
    pepperoni,
    mushrooms,
    pineapple,
    cheese,
    mozzarella,
    onion,
    tomato_sauce,
    Jalpeno,

}
