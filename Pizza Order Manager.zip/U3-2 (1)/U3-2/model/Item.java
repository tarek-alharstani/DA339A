package model;

/**
 * Interface klass gällande alla Item som kopplas till Product och vidare till subklasser.
 */
public interface Item
{
    double price = 0;
    String name = null;

    /**
     * Metod för att få ett pris
     * @return returnerar en double av pris.
     */
    double getPrice();

    /**
     * Metod för att få namn
     * @return returnerar en sträng av namn
     */
    String getName();

    /**
     * Metod för att returnera en sträng
     * @return returnerar sträng av namn och pris
     */
    String toString();

}
