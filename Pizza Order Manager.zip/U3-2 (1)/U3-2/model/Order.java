package model;

import java.util.ArrayList;

/**
 * Klass som håller koll på ordrar med hjälp av objekt från Product. Skapar en ArrayList med valda produkter.
 * @author Tarek/ Mohammed
 */
public class Order
{
    ArrayList<Product> product = new ArrayList<>();  // En lista (ArrayList) som innehåller produkter i ordern
    private double price; // Priset på ordern.
    private boolean pizzaOK = false; // En boolean-variabel som indikerar om en pizza är tillåten i ordern.
    private int id; // Orderns unika identifierare.

    /**
     * Konstruktor för order som visar ID och pris.
     * @param id
     */
    public Order(int id )
    {
        price = 0; // Sätter initialpriset för ordern till 0.
        this.id = id; // Tilldelar ordern det unika identifieraren som skickas som parameter.
    }

    /**
     * Metod för att genom boolean dubbelkolla att en pizza har beställts och inte bara dryck.
     * @return returnerar boolean om pizza finns med i order
     */
    public boolean isPizzaOK() {
        return pizzaOK;
    }

    /**
     * Metod för att sätta ett ID på en order.
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Metod som först kontrollerar att en instans av Pizza finns med i order och sedan lägger till produkt och pris på
     * produkten i en order.
     * @param product
     */
    public void addProduct(Product product)
    {
        if (product instanceof Pizza) {
            pizzaOK = true;
        }
       this.product.add(product); // Lägger till produkten i listan av produkter i ordern.
       price = price + product.getPrice(); // Ökar det totala priset för ordern med priset på den tillagda produkten.
    }

    /**
     * Metod för att skapa strängar av orderinformation som sedan kan skrivas ut i GUI.
     * @return returnerar en sträng med information om produkt/order.
     */
    public String[] getOrdersInfo(){
        String []infoStrings = new String[product.size()]; // Skapar en array med storlek baserad på antalet produkter i ordern.
        for (int i =0; i<product.size(); i++){
            infoStrings[i] = product.get(i).toString(); // Konverterar varje produkt till en sträng och lagrar den i arrayen.
        }
        return infoStrings; // Returnerar arrayen med information om produkterna i ordern.
    }

    /**
     * Metod för att hämta pris.
     * @return returnerar en double av pris.
     */
    public double getPrice() {
        return price;
    }

    /**
     * Metod för att generera en sträng med orderinformation som inkluderar orderns ID och pris.
     * @return returnerar sträng med ID och pris.
     */

    public String toString()
    {
        String textOut = String.format("%s %s", id + ", " ,price + "kr");
        return textOut;

    }
}
