package model;

import java.util.Arrays;

/**
 * Subklass till Abstrakta klassen Product för att hantera produkter av typ Pizza
 @author Tarek/ Mohammed
 */
public class Pizza extends Product
{

    private PizzaToppings[] toppings;

    /**
     * Konstruktor för objekt av klassen Pizza
     * @param pizzaName
     * @param pizzaPrice
     * @param toppings
     *
     */
    public Pizza(String pizzaName, int pizzaPrice, PizzaToppings[] toppings)
    {
        super(pizzaName, pizzaPrice);
        this.toppings = toppings;
    }
//region Getters & Setters
    public model.PizzaToppings[] getToppings() {
        return toppings;
    }

    public void setToppings(model.PizzaToppings[] toppings) {
        this.toppings = toppings;
    }
//endregion

    /**
     * Metod för att skapa en sträng av pizza objektet.
     *
     * @return returnerar sträng av pizza med namn, pris och toppings
     */
    @Override
    public String toString() {
        return "Pizza{" +
                "toppings=" + Arrays.toString(toppings) +
                '}';
    }


}
