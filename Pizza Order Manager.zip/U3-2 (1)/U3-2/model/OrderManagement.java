package model;

import java.util.ArrayList;

/**
 * Klass som lagrar alla ordrar ifrån Order klassen.
 * @author Tarek/ Mohammed
 */
public class OrderManagement
{
    ArrayList <Order> allOrders;

    /**
     * Skapar ny lista av alla ordrar som är gjorda av användaren
     */
    public OrderManagement(){
        allOrders = new ArrayList<>();
    }

    /**
     * Skapar själva ordern och ger den ett ID med objekt från Order
     * @param order : Den order som ska läggas till.
     */
    public void addOrder (Order order){
        order.setId(getCurrentId()); // Tilldelar ordern ett unikt identifierare.
        allOrders.add(order); // Lägger till ordern i listan av alla ordrar.
    }

    /**
     * Metod för att fylla ArrayList med lagrade ordrar.
     * @return returnerar en ArrayList med alla order sparade.
     */
    public Order[] getAllOrders() {
        Order [] returnOder = new Order[allOrders.size()]; // Skapar en array med storlek baserad på antalet befintliga ordrar.
        for (int i =0; i < allOrders.size(); i ++){
            returnOder[i] = allOrders.get(i); // Kopierar varje Order-objekt från listan till arrayen.
        }
        return returnOder; // Returnerar arrayen med alla ordrar.
    }

    /**
     * Skapar ett ID för varje order.
     * @return returnerar en orders ID, dvs index på ordern.
     */
    public int getCurrentId(){

        return allOrders.size(); // Returnerar storleken på listan över alla ordrar som ett unikt ID.
    }
}
