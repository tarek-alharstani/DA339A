package model;

/**
 * Sublklassens syfte är skapa dryckesobjekt med hjälp av abstrakta klassen produkt.
 *
 */

public class Drinks extends model.Product
{
    /**
     * Konstruktor för dryck som ärver av klassen Product
     * @param name // ger information om vad name förväntas vara och hur den bör användas
     * @param price // ger information om vad price förväntas vara och hur den bör användas
     */
    public Drinks(String name, int price)
    {  // Anropa konstruktor i överordnad klass (Product) med namn och pris
        super(name, price);
    }


    /**
     * Metod som genererar en sträng av namn och pris på en dryck.
     * @return En sträng som visar namn och pris.
     */
    @Override
    public String toString() {
        // Anropa toString-metoden i överordnad klass (Product) och returnera resultatet
        String textOut = super.toString() ;
        return textOut;
    }
}

