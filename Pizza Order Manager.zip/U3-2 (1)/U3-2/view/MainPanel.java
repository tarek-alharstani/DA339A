package view;

import javax.swing.*;

public class MainPanel extends JPanel {
    private LPanel lPanel; // Vänster panel
    private RPanel rPanel; // Höger panel


    // Konstruktor för att skapa en instans av MainPanel
    public MainPanel(int width, int height, MainFrame mainFrame) {
        super(null); // Använder null layout
        this.setSize(width, height);

        // Skapar vänster panel och lägger till den i MainPanel
        lPanel = new LPanel(width / 2 +60, height, mainFrame);
        add(lPanel);
        // Skapar höger panel och lägger till den i MainPanel
        rPanel = new RPanel(width / 2 +70, height, mainFrame);
        add(rPanel);
    }

    // Metod för att hämta referensen till vänster panel
    protected LPanel getLeftPanel() {

        return lPanel;
    }

    // Metod för att hämta referensen till höger panel

    protected RPanel getRightPanel() {

        return rPanel;
    }

}
