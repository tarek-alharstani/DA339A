package view;

import controller.Controller;

import javax.swing.*;

public class MainFrame extends JFrame {
    private MainPanel mainPanel; // Huvudpanelen
    private Controller controller; // Controller-objekt för att hantera interaktion och logik

    // Konstruktor för att skapa en instans av MainFrame
    public MainFrame(int width, int height, Controller controller) {
        super("Restaurant"); // Sätter titeln på fönstret
        this.controller = controller; // Tilldelar controller-objektet
        this.setResizable(false); // Gör fönstret icke-ändringsbart i storlek
        this.setSize(width, height); // Sätter fönstrets storlek
        this.mainPanel = new MainPanel(width, height, this); // Skapar huvudpanelen
        this.setContentPane(mainPanel); // Sätter huvudpanelen som innehållet i fönstret
        this.setVisible(true); // Gör fönstret synligt
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  // Stänger programmet när fönstret stängs

    }

    /**
     * Metoden används för att uppdatera informationen i den vänstra panelen (LPanel) i huvudfönstret     *
     * @param informationArray An array of String where each element will be shown
     *                        one line in the panel.
     */
    public void populateLeftPanel(String[] informationArray){
        mainPanel.getLeftPanel().populateList(informationArray);
    }

    /**
     * Denna metod sätter informationen i HÖGER panel av huvudfönstret.
     *
     * @param informationArray En array av strängar där varje element kommer att visas
     *                         som en rad i panelen.
     */
    public void populateRightPanel(String[] informationArray){
        mainPanel.getRightPanel().populateList(informationArray);
    }

    /**
     * Denna metod tar bort informationen i HÖGER panel av huvudfönstret.
     * Det finns vissa problem med detta i koden och "spökobjekt" kan
     * visas i listvyn längst upp i listan efter användning av denna metod.
     * Detta kan orsaka att valda index förlorar synkronisering om det används.
     */
    public void clearRightPanel(){
        mainPanel.getRightPanel().clearList();
    }

    /**
     * Denna metod returnerar indexvärdet som en int för den markerade raden
     * i listan i den vänstra panelen av huvudfönstret.
     *
     * @return indexet för den markerade raden som en int. Om ingen markering finns, returneras -1.
     */

    public int getSelectionLeftPanel(){
        return mainPanel.getLeftPanel().getLeftPanelList().getSelectedIndex();
    }

    /**
     * Denna metod sätter en text som visas längst till höger i
     * fönstret ovanför den högra listpanelen.
     *
     * @param newText den text som visas i gränssnittet
     */

    public void setTextCostLabelRightPanel(String newText){
        mainPanel.getRightPanel().setTextCostLabel(newText);
    }

    /**
     * Denna metod sätter en text som visas lite till höger om
     * mitten av fönstret ovanför den högra listpanelen.
     *
     * @param newText den text som visas i gränssnittet
     */

    public void setTextTitleLabelRightPanel(String newText){
        mainPanel.getRightPanel().setTextTitleLabel(newText);
    }

    /**
     * Denna metod inaktiverar möjligheten att trycka på knappen märkt "Food".
     */

    public void disableFoodMenuButton(){
        mainPanel.getLeftPanel().getBtnShowFood().setEnabled(false);
    }


    /**
     * Denna metod inaktiverar möjligheten att trycka på knappen märkt "Drinks".
     */

    public void disableDrinksMenuButton(){
        mainPanel.getLeftPanel().getBtnShowDrinks().setEnabled(false);
    }


    /**
     * Denna metod inaktiverar möjligheten att trycka på knappen märkt "Add".
     */

    public void disableAddMenuButton(){
        mainPanel.getLeftPanel().getBtnAddSelectionToOrder().setEnabled(false);
    }

    /**
     * Denna metoden avbryter möjligheten att trycka på knappen märkt "Order".
     */

    public void disableOrderButton(){
        mainPanel.getRightPanel().getBtnCreateOrder().setEnabled(false);
    }

    /**
     * Denna metod inaktiverar möjligheten att trycka på knappen märkt "View order".
     */

    public void disableViewSelectedOrderButton(){
        mainPanel.getRightPanel().getBtnViewSelectedOrder().setEnabled(false);
    }

    /**
     * Denna metod aktiverar alla knappar i gränssnittet så att de kan tryckas.
     */

    public void enableAllButtons(){
        mainPanel.getLeftPanel().getBtnShowFood().setEnabled(true);
        mainPanel.getLeftPanel().getBtnShowDrinks().setEnabled(true);
        mainPanel.getLeftPanel().getBtnClear().setEnabled(true);
        mainPanel.getLeftPanel().getBtnAddSelectionToOrder().setEnabled(true);
        mainPanel.getLeftPanel().getShowOrderHistory().setEnabled(true);
        mainPanel.getRightPanel().getBtnCreateOrder().setEnabled(true);
        mainPanel.getRightPanel().getBtnViewSelectedOrder().setEnabled(true);
    }

    /**
     * Denna metod anropas av andra delar av gränssnittet när en knapp trycks.
     * Metoden buttonPressed i klassen Controller anropas och typen av
     * tryckt knapp skickas som ett argument.
     *
     * @param pressedButton typen av knapp
     * @return
     * @see ButtonType
     */

    public void buttonPressed(ButtonType pressedButton){
        controller.buttonPressed(pressedButton);

    }
}
