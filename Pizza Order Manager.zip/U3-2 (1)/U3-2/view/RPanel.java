package view;
// inkluderar olika Swing-metoder som används i klassen.
import javax.swing.*;
// RPanel-klassen. Den utökar (ärver från) JPanel
/**
 *Dessa är instansvariabler som används för att lagra referenser
 * till olika Swing-komponenter (t.ex., JList, JButton, JLabel)
 * och andra variabler för att lagra bredd och höjd av panelen.
 *
 */

public class RPanel extends JPanel {
    private MainFrame mainFrame;
    private JList<Object> rightPanelList;

    private JButton btnOrder;

    private JButton btnViewSelectedOrder;
    private JLabel lblTitle;
    private JLabel lblCost;
    private int width;
    private int height;

    // Konstruktor för att skapa en instans av RPanel
    //Den tar emot bredd, höjd och en referens till en MainFrame
    public RPanel(int width, int height, MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        this.setLayout(null);
        this.width = width;
        this.height = height;
        this.setSize(width, height);
        setLocation(width, 0);
        setUp(); // Anropar den privata metoden setUp() för att konfigurera komponenter
    }

    private void setUp() {
        // (setUp) används av konstruktorn för att ställa in och skapa
        // olika Swing-komponenter inuti panelen.
        lblTitle = new JLabel("CURRENT ORDER");
        lblTitle.setLocation(2, 0);
        lblTitle.setSize((width / 2)-100, 20);
        this.add(lblTitle);

        lblCost = new JLabel("TOTAL COST: 0");
        lblCost.setLocation((width / 2) -90, 0);
        lblCost.setSize((width/2)-100, 20);
        this.add(lblCost);

        rightPanelList = new JList<>();
        rightPanelList.setLocation(0, 23);
        rightPanelList.setSize(width, height - 100);
        this.add(rightPanelList);

        btnOrder = new JButton("Order");
        btnOrder.setEnabled(true);
        btnOrder.setSize(width / 5, 30);
        btnOrder.setLocation(0, height - 75);
        btnOrder.addActionListener(l -> mainFrame.buttonPressed(ButtonType.Order));
        this.add(btnOrder);

        btnViewSelectedOrder = new JButton("View order");
        btnViewSelectedOrder.setEnabled(false);
        btnViewSelectedOrder.setSize(width / 5, 30);
        btnViewSelectedOrder.setLocation(width / 5, height - 75);
        btnViewSelectedOrder.addActionListener(l -> mainFrame.buttonPressed(ButtonType.ViewOrder));
        this.add(btnViewSelectedOrder);

    }

    /**
    * Tar emot en array av strängar (informationArray).
    * Använder den för att fylla JList-komponenten (rightPanelList) med information.
     */
    protected void populateList(String[] informationArray){
        rightPanelList.setListData(informationArray);
    }

    /**
     * Denna metod tar bort informationen i panelens listvy.
     * Det finns vissa problem med detta i koden och "spökobjekt" kan
     * visas i listvyn längst upp i listan efter användning av denna metod.
     * Detta kan orsaka att valda index förlorar synkronisering om det används.
     *
     * Detta är en "hack" och inte en perfekt lösning - GUI:er är irriterande att arbeta med!
     *
     * Flera lösningar har testats men ingen har fungerat till belåtenhet.
     * Var vänlig meddela lärarna om du stöter på en lösning som faktiskt fungerar bra.
     */

    // Metod för att rensa JList

    protected void clearList(){
        String[] defaultString = new String[1];
        defaultString[0] = "Nothing selected";
        populateList(defaultString);
    }
    // Metod för att sätta textetiketten för titeln

    protected void setTextTitleLabel(String labelText){
        lblTitle.setText(labelText);
    }

    // Metod för att sätta textetiketten för den totala kostnaden
    protected void setTextCostLabel(String labelText){
        lblCost.setText(labelText);
    }

    // Metod för att hämta referensen till knappen för att skicka en beställning
    protected JButton getBtnCreateOrder(){ return btnOrder;}

    // Metod för att hämta referensen till knappen för att visa den valda ordern
    protected JButton getBtnViewSelectedOrder() {return btnViewSelectedOrder;}
}
