package view;

public enum ButtonType {
    Add,
    Drinks,
    Food,
    Clear,
    NoChoice,
    Order,
    OrderHistory,
    ViewOrder,
}
