package View;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * The Gui class represents the graphical user interface for the Treasure Hunt Game.
 * It sets up the game board, player panels, and input fields for player names.
 *
 * @author Tarek
 * @author Mohammed
 */
public class Gui extends JFrame {

    private JTextField player1Field;
    private JTextField player2Field;
    private JLabel player1CrewMembers;
    private JLabel player2CrewMembers;
    private Controller controller;

    private JLabel player1Label;
    private JLabel player2Label;
    private JLabel player1Points;
    private JLabel player2Points;
    private JLabel turnLabel;
    private JPanel gameBoard;
    private JButton[][] buttons;

    /**
     * Constructs a Gui object and initializes the GUI components.
     *
     * @param controller the controller for handling game logic
     * @author Mohammed
     * @author Tarek
     */
    public Gui(Controller controller) {
        this.controller = controller;
        setTitle("Treasure Hunt Game");
        setSize(800, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        initInputPanel();
        initGameBoard();
        initPlayerPanels();
        setBoardEnabled(false);
    }

    /**
     * Initializes the input panel for entering player names and starting the game.
     *
     * @author Tarek
     * @author Mohammed
     */
    public void initInputPanel() {
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(6, 2));

        inputPanel.add(new JLabel("Player 1:"));
        player1Field = new JTextField();
        inputPanel.add(player1Field);

        inputPanel.add(new JLabel("Player 2:"));
        player2Field = new JTextField();
        inputPanel.add(player2Field);

        JButton playButton1 = new JButton("Play with Board 1");
        inputPanel.add(playButton1);

        JButton playButton2 = new JButton("Play with Board 2");
        inputPanel.add(playButton2);

        JButton resetButton = new JButton("Reset");
        inputPanel.add(resetButton);

        turnLabel = new JLabel("Player 1's Turn");
        inputPanel.add(turnLabel);

        add(inputPanel, BorderLayout.NORTH);

        playButton1.addActionListener(new ActionListener() {
            @Override
            /**
             * Handles the action event for playButton1.
             *
             * @param e the action event that occurred
             * @author Mohammed
             * @author Tarek
             */
            public void actionPerformed(ActionEvent e) {
                startGame(1);
            }
        });

        playButton2.addActionListener(new ActionListener() {
            @Override
            /**
             * Handles the action event for playButton2.
             *
             * @param e the action event that occurred
             * @author Tarek
             * @author Mohammed
             */
            public void actionPerformed(ActionEvent e) {
                startGame(2);
            }
        });

        resetButton.addActionListener(new ActionListener() {
            @Override
            /**
             * Handles the action event for resetButton.
             *
             * @param e the action event that occurred
             * @author Mohammed
             * @author Tarek
             */
            public void actionPerformed(ActionEvent e) {
                resetGame();
            }
        });
    }

    /**
     * Displays a message dialog with the specified message.
     *
     * @param message the message to display
     * @author Tarek
     * @author Mohammed
     */
    public void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    /**
     * Displays a game finished message dialog with the specified message.
     *
     * @param message the message to display
     * @author Mohammed
     * @author Tarek
     */
    public void showGameFinishedMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    /**
     * Initializes the game board with buttons representing each block.
     *
     * @author Tarek
     * @author Mohammed
     */
    public void initGameBoard() {
        gameBoard = new JPanel();
        gameBoard.setLayout(new GridLayout(10, 10));
        buttons = new JButton[10][10];

        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                buttons[i][j] = new JButton();
                final int x = i;
                final int y = j;
                buttons[i][j].addActionListener(new ActionListener() {
                    @Override
                    /**
                     * Handles the action event for a game board button.
                     *
                     * @param e the action event that occurred
                     * @author Mohammed
                     * @author Tarek
                     */
                    public void actionPerformed(ActionEvent e) {
                        controller.handleButtonClick(x, y);
                    }
                });
                gameBoard.add(buttons[i][j]);
            }
        }

        add(gameBoard, BorderLayout.CENTER);
    }

    /**
     * Initializes the player panels displaying names, points, and crew members for each player.
     *
     * @author Tarek
     * @author Mohammed
     */
    public void initPlayerPanels() {
        JPanel player1Panel = new JPanel();
        player1Panel.setLayout(new BorderLayout());
        player1Label = new JLabel("Player 1: ");
        player1Points = new JLabel("Points: 0");
        player1CrewMembers = new JLabel("Crew Members: 3");
        player1Panel.add(player1Label, BorderLayout.NORTH);
        player1Panel.add(player1Points, BorderLayout.CENTER);
        player1Panel.add(player1CrewMembers, BorderLayout.SOUTH);

        JPanel player2Panel = new JPanel();
        player2Panel.setLayout(new BorderLayout());
        player2Label = new JLabel("Player 2: ");
        player2Points = new JLabel("Points: 0");
        player2CrewMembers = new JLabel("Crew Members: 3");
        player2Panel.add(player2Label, BorderLayout.NORTH);
        player2Panel.add(player2Points, BorderLayout.CENTER);
        player2Panel.add(player2CrewMembers, BorderLayout.SOUTH);

        add(player1Panel, BorderLayout.WEST);
        add(player2Panel, BorderLayout.EAST);
    }

    /**
     * Updates the crew members count for both players.
     *
     * @author Mohammed
     * @author Tarek
     */
    public void updateCrewMembers() {
        player1CrewMembers.setText("Crew Members: " + controller.getPlayer1CrewMembers());
        player2CrewMembers.setText("Crew Members: " + controller.getPlayer2CrewMembers());
    }

    /**
     * Starts the game with the specified board type and sets up player names.
     *
     * @param boardType the type of board to use (1 or 2)
     * @author Tarek
     * @author Mohammed
     */
    public void startGame(int boardType) {
        String player1Name = player1Field.getText();
        String player2Name = player2Field.getText();

        if (player1Name.isEmpty() || player2Name.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Välj namn för båda spelarna.");
        } else if (player1Name.equals(player2Name)) {
            JOptionPane.showMessageDialog(null, "Spelarnas namn måste vara olika.");
        } else {
            JOptionPane.showMessageDialog(null, "Spelet har börjat. Lycka till.");
            player1Label.setText("Player 1: " + player1Name);
            player2Label.setText("Player 2: " + player2Name);
            controller.startGame(player1Name, player2Name, boardType);
            setBoardEnabled(true);
        }
    }

    /**
     * Updates the specified button on the game board with new text, color, and enabled state.
     *
     * @param x       the x-coordinate of the button
     * @param y       the y-coordinate av the button
     * @param enabled whether the button should be enabled or disabled
     * @param text    the text to display on the button
     * @param color   the background color of the button
     * @author Mohammed
     * @author Tarek
     */
    public void updateButton(int x, int y, boolean enabled, String text, Color color) {
        JButton button = buttons[x][y];
        button.setEnabled(enabled);
        button.setText(text);
        button.setBackground(color);

        // Justera knappstorlek baserat på textens längd
        int width = Math.max(text.length() * 12, 50); // Dynamiskt sätt bredd baserat på textlängd, min bredd 50
        int height = 50; // Behåll höjden konstant
        button.setPreferredSize(new Dimension(width, height));

        // Sätt en lägre fontstorlek om texten är för lång för att passa
        if (text.length() > 5) {
            button.setFont(new Font("Arial", Font.PLAIN, 10)); // Justera fontstorleken för längre text
        } else {
            button.setFont(new Font("Arial", Font.PLAIN, 12)); // Standard fontstorlek
        }
    }

    /**
     * Updates the scores displayed for both players.
     *
     * @param player1Score the score of player 1
     * @param player2Score the score of player 2
     * @author Tarek
     * @author Mohammed
     */
    public void updateScores(int player1Score, int player2Score) {
        player1Points.setText("Points: " + player1Score);
        player2Points.setText("Points: " + player2Score);
        updateCrewMembers(); // Update the crew members count after each move
    }

    /**
     * Resets the game board to its initial state, clearing all button text and colors.
     *
     * @author Mohammed
     * @author Tarek
     */
    public void resetBoard() {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                updateButton(i, j, true, "", null);
            }
        }
    }

    /**
     * Highlights the specified button on the game board with a green background.
     *
     * @param x the x-coordinate of the button
     * @param y the y-coordinate of the button
     * @author Tarek
     * @author Mohammed
     */
    public void highlightButton(int x, int y) {
        buttons[x][y].setBackground(Color.orange);
    }

    /**
     * Updates the turn label with the specified text indicating whose turn it is.
     *
     * @param text the text to display on the turn label
     * @author Mohammed
     * @author Tarek
     */
    public void updateTurnLabel(String text) {
        turnLabel.setText(text);
    }

    /**
     * Displays a message indicating that the game has finished.
     *
     * @author Tarek
     * @author Mohammed
     */
    public void showGameFinishedMessage() {
        JOptionPane.showMessageDialog(this, "Game finished!");
    }

    /**
     * Enables or disables all buttons on the game board based on the specified state.
     *
     * @param enabled whether the buttons should be enabled or disabled
     * @author Mohammed
     * @author Tarek
     */
    public void setBoardEnabled(boolean enabled) {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                buttons[i][j].setEnabled(enabled);
            }
        }
    }

    /**
     * Resets the game state to its initial configuration, including clearing fields and scores.
     *
     * @author Tarek
     * @author Mohammed
     */
    public void resetGame() {
        resetBoard();
        player1Points.setText("Points: 0");
        player2Points.setText("Points: 0");
        player1Label.setText("Player 1: ");
        player2Label.setText("Player 2: ");
        turnLabel.setText("Player 1's Turn");
        setBoardEnabled(false);
        player1Field.setText("");
        player2Field.setText("");
    }
}
