package Controller;

import Model.*;
import View.Gui;
import View.Leaderboard;

import java.awt.*;
import java.io.*;
import java.util.*;
import java.util.List;

/**
 * Manages the game logic including player turns, board setup, treasure placement, and leaderboard operations.
 *
 * @author Tarek & Mohammad
 */
public class Controller {
    private boolean player1Turn = true;
    private GameItem[][] boardItems;
    private Gui view;
    private Player player1;
    private Player player2;

    private Leaderboard leaderboard;
    private Map<String, Integer> remainingTreasures;
    private Map<String, Integer> treasurePoints;
    private static final String LEADERBOARD_FILE = "leaderboard.txt";

    /**
     * Constructs the Controller, initializing the game board and treasure points.
     *
     * @author Tarek
     */
    public Controller() {
        boardItems = new GameItem[10][10]; // Håller koll på alla spelobjekt (som skatter och fällor) på spelbrädet
        remainingTreasures = new HashMap<>();  // Håller koll på hur många skatter som återstår av varje typ
        treasurePoints = new HashMap<>();    // Lagrar poängvärdet för varje typ av skatt
        treasurePoints.put("Mega", 50);
        treasurePoints.put("Major", 10);
        treasurePoints.put("Minor", 20);
        treasurePoints.put("Grand", 30);
        treasurePoints.put("Mini", 15);
        Gui gui = new Gui(this); // Passa referensen av kontrollern till GUI
        Leaderboard leaderboard = new Leaderboard();

        // Sätt GUI och leaderboard som kontrollerarens vyer
        setView(gui);
        setLeaderboard(leaderboard);

        // Gör GUI och leaderboard synliga
        gui.setVisible(true);
        leaderboard.setVisible(true);
    }

    /**
     * Sets the GUI view for the game.
     *
     * @param view the GUI view to set
     * @author Mohammed
     */
    public void setView(Gui view) {
        this.view = view;
    }

    /**
     * Sets the leaderboard and updates it from the file.
     *
     * @param leaderboard the leaderboard to set
     * @author Tarek
     */
    public void setLeaderboard(Leaderboard leaderboard) {
        this.leaderboard = leaderboard;
        updateLeaderboardFromFile();
    }

    /**
     * Starts the game with the specified player names and board type.
     *
     * @param player1Name the name of player 1
     * @param player2Name the name of player 2
     * @param boardType   the type of board to initialize (1 or 2)
     * @author Mohammed
     */
    public void startGame(String player1Name, String player2Name, int boardType) {
        player1 = new Player(player1Name);
        player2 = new Player(player2Name);
        player1Turn = true;
        if (boardType == 1) {
            initializeBoard1();
        } else if (boardType == 2) {
            initializeBoard2();
        }
        if (view != null) {
            view.resetBoard();
            view.updateScores(player1.getPoints(), player2.getPoints());
            view.updateTurnLabel("Player 1's Turn");
        }
    }

    /**
     * Initializes board type 1 with predefined treasures and traps.
     *
     * @author Tarek
     */
    public void initializeBoard1() {
        clearBoard();
        placeTreasure(6, 8, "Mega", Color.cyan);
        placeTreasure(6, 9, "Mega", Color.cyan);
        placeTreasure(7, 8, "Mega", Color.cyan);
        placeTreasure(7, 9, "Mega", Color.cyan);

        placeTreasure(1, 0, "Major", new Color(205, 127, 50));

        placeTreasure(2, 6, "Minor", Color.magenta);
        placeTreasure(3, 6, "Minor", Color.magenta);
        placeTreasure(4, 6, "Minor", Color.magenta);

        placeTreasure(4, 1, "Grand", Color.YELLOW);
        placeTreasure(4, 2, "Grand", Color.YELLOW);
        placeTreasure(5, 2, "Grand", Color.YELLOW);
        placeTreasure(4, 3, "Grand", Color.YELLOW);

        placeTreasure(8, 0, "Mini", new Color(176, 176, 176));
        placeTreasure(9, 0, "Mini", new Color(176, 176, 176));

        placeTreasure(5, 6, "Bonus", Color.BLUE);
        placeTreasure(0, 8, "Bonus", Color.BLUE);
        placeTreasure(9, 2, "Bonus", Color.BLUE);
        placeTreasure(3, 0, "Bonus", Color.BLUE);

        placeTreasure(0, 3, "Trap", Color.RED);
        placeTreasure(5, 3, "Trap", Color.RED);
        placeTreasure(8, 4, "Trap", Color.RED);
        placeTreasure(4, 8, "Trap", Color.RED);

        initializeTreasures();
    }

    /**
     * Initializes board type 2 with predefined treasures and traps.
     *
     * @author Mohammed
     */
    public void initializeBoard2() {
        clearBoard();
        placeTreasure(8, 1, "Trap", Color.RED);
        placeTreasure(4, 7, "Trap", Color.RED);
        placeTreasure(6, 5, "Trap", Color.RED);
        placeTreasure(1, 7, "Trap", Color.RED);
        placeTreasure(8, 9, "Trap", Color.RED);
        placeTreasure(3, 2, "Trap", Color.RED);
        placeTreasure(5, 3, "Trap", Color.RED);
        placeTreasure(7, 6, "Trap", Color.RED);
        placeTreasure(3, 8, "Trap", Color.RED);
        placeTreasure(6, 2, "Trap", Color.RED);

        // Mega treasures
        placeTreasure(4, 9, "Mega", Color.cyan);
        placeTreasure(4, 8, "Mega", Color.cyan);
        placeTreasure(5, 8, "Mega", Color.cyan);
        placeTreasure(5, 9, "Mega", Color.cyan);

        // Major treasures
        placeTreasure(9, 8, "Major", new Color(205, 127, 50));

        // Minor treasures
        placeTreasure(8, 3, "Minor", Color.magenta);
        placeTreasure(8, 4, "Minor", Color.magenta);
        placeTreasure(8, 5, "Minor", Color.magenta);

        // Grand treasures
        placeTreasure(1, 8, "Grand", Color.YELLOW);
        placeTreasure(1, 9, "Grand", Color.YELLOW);
        placeTreasure(1, 7, "Grand", Color.YELLOW);
        placeTreasure(2, 7, "Grand", Color.YELLOW);

        // Mini treasures
        placeTreasure(3, 5, "Mini", Color.DARK_GRAY);
        placeTreasure(3, 4, "Mini", Color.DARK_GRAY);

        placeTreasure(3, 3, "Bonus", Color.BLUE);
        placeTreasure(2, 3, "Bonus", Color.BLUE);

        initializeTreasures();
    }

    /**
     * Clears the game board by setting all positions to null.
     *
     * @author Tarek
     */
    public void clearBoard() {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                boardItems[i][j] = null;
            }
        }
    }

    /**
     * Returns the number of crew members for player 1.
     *
     * @return the number of crew members
     * @author Mohammed
     */
    public int getPlayer1CrewMembers() {
        return player1.getCrewMembers();
    }

    /**
     * Returns the number of crew members for player 2.
     *
     * @return the number of crew members
     * @author Tarek
     */
    public int getPlayer2CrewMembers() {
        return player2.getCrewMembers();
    }

    /**
     * Checks if the game is over based on crew members.
     *
     * @return true if either player has 0 crew members, otherwise false
     * @author Mohammed
     */
    public boolean isGameOver() {
        return player1.getCrewMembers() == 0 || player2.getCrewMembers() == 0;
    }

    /**
     * Initializes the count of each type of treasure available in the game.
     *
     * @author Tarek
     */
    public void initializeTreasures() {
        remainingTreasures.put("Mega", 4);
        remainingTreasures.put("Major", 1);
        remainingTreasures.put("Minor", 3);
        remainingTreasures.put("Grand", 4);
        remainingTreasures.put("Mini", 2);
    }

    /**
     * Places a treasure or trap on the board at the specified coordinates.
     *
     * @param x     the x-coordinate on the board
     * @param y     the y-coordinate on the board
     * @param type  the type of item (treasure or trap) to place
     * @param color the color of the item
     * @author Mohammed
     */
    public void placeTreasure(int x, int y, String type, Color color) {
        GameItem item = null;

        // Skapa rätt objekt beroende på typen
        switch (type) {
            case "Mega":
                item = new MegaTreasure();
                break;
            case "Major":
                item = new MajorTreasure();
                break;
            case "Minor":
                item = new MinorTreasure();
                break;
            case "Grand":
                item = new GrandTreasure();
                break;
            case "Mini":
                item = new MiniTreasure();
                break;
            case "Trap":
                item = new Trap();
                break;
            case "Bonus":
                item = new Bonus();
                break;
        }

        boardItems[x][y] = item;

        // Nu skickar vi den korrekta typen som text till GUI:et för alla skatter
        view.updateButton(x, y, true, type, color);
    }

    /**
     * Informs the player about the effect of activating a trap.
     *
     * @param type the type of trap (e.g., "Trap")
     * @author Tarek
     */
    public void informPlayerTrapEffect(String type) {
        // Visa meddelande om att spelaren förlorade en besättningsmedlem
        view.showMessage("Aj! Du grävde upp en " + type + " och förlorade en besättningsmedlem.");
    }

    /**
     * Handles a button click event by updating the game state and managing player turns.
     *
     * @param x the x-coordinate of the clicked button
     * @param y the y-coordinate of the clicked button
     * @author Mohammed
     */
    public void handleButtonClick(int x, int y) {
        Player currentPlayer = player1Turn ? player1 : player2; // Initiera spelaren
        GameItem item = boardItems[x][y];

        if (item != null) {  // Finns skatt
            String type = item.getType(); // Hämta objektets typ

            // Hantera andra typer av objekt (skatter eller fällor).
            if (remainingTreasures.containsKey(type)) { // Kontrollera om det finns kvar skatter av den aktuella typen.
                remainingTreasures.put(type, remainingTreasures.get(type) - 1); // Minska antalet kvarvarande skatter av denna typ med 1
                view.updateButton(x, y, false, type, item.getColor()); // Uppdaterar knappen

                // Kontrollera om detta var den sista skatten av denna typ.
                if (remainingTreasures.get(type) == 0) {  // Om inga fler skatter av denna typ finns kvar
                    int points = treasurePoints.get(type); // Hämta poängvärdet för denna skatt
                    currentPlayer.addPoints(points); // Lägg till poängen till spelaren

                    // Anropa metoden för att informera spelaren om poängen de får för att samla alla skatter av denna typ
                    informPlayerAboutPointsForAllTreasures(type);

                    // Markera skatterna av denna typ på brädet (t.ex. genom att ändra bakgrundsfärgen på knappar)
                    highlightTreasure(type);
                }

            } else { // Hantera fällor
                if (type.equals("Trap")) {  // Om det är en fälla
                    item.updatePoints(currentPlayer);  // Här anropas redan `removeCrewMember(1)` i Trap-klassen

                    // Informera spelaren om effekten av att aktivera en fälla
                    informPlayerTrapEffect(type);

                    // Uppdatera knappen för fällan på spelbrädet
                    view.updateButton(x, y, false, type, item.getColor());
                }
            }

            // Hantera Bonusobjektet
            if (type.equals("Bonus")) {
                currentPlayer.addCrewMember(1);  // Öka antalet besättningsmedlemmar med +1
                view.showMessage(currentPlayer.getName() + " grävde upp en bonus och fick en extra besättningsmedlem!");
                view.updateButton(x, y, false, "Bonus", item.getColor());
            }
        } else { // Tom ruta
            view.updateButton(x, y, false, "X", null);
        }
        //
        // Kontroll om spelet är slut på grund av besättningsmedlemmar:
        if (isGameOver()) {
            Player winner = player1.getCrewMembers() > 0 ? player1 : player2;
            view.showGameFinishedMessage(winner.getName() + " har vunnit spelet!");
            view.setBoardEnabled(false);  // Användarinteraktionen stängs av
            view.updateCrewMembers();
            return;
        }
        // Kontrollera om den aktuella spelaren har slut på besättningsmedlemmar
        if (currentPlayer.getCrewMembers() <= 0) {
            view.showMessage("Spelare " + currentPlayer.getName() + " har förlorat alla besättningsmedlemmar!");
            endGame(player1Turn ? player2 : player1); // Slutar spelet och deklarerar den andra spelaren som vinnare
            return;
        }
        // Uppdatera GUI för att reflektera spelets aktuella status.
        view.updateScores(player1.getPoints(), player2.getPoints());
        player1Turn = !player1Turn; // Växla tur
        view.updateTurnLabel(player1Turn ? "Spelare 1:s tur" : "Spelare 2:s tur");

        // Kontrollera om spelet är färdigt (inga skatter kvar)
        if (isGameFinished()) {
            view.showGameFinishedMessage("Spelet är över!");
            updateLeaderboard();
            view.setBoardEnabled(false);
        }
    }

    /**
     * Informs the player about the points they receive when all treasures of a certain type have been collected.
     *
     * @param type the type of treasure that has been fully collected
     * @author Tarek
     */
    public void informPlayerAboutPointsForAllTreasures(String type) {
        // Hämta poängvärdet för skatten
        int points = treasurePoints.get(type);

        // Visa meddelande till spelaren
        view.showMessage("Grattis! Du har grävt upp alla " + type + "-skatter och fått " + points + " poäng!");
    }

    /**
     * Ends the game by declaring the winner and updating the leaderboard.
     *
     * @param winner the player who has won the game
     * @author Mohammed
     */
    private void endGame(Player winner) {
        view.showMessage("Spelet är slut! Vinnaren är " + winner.getName() + "!");
        updateLeaderboard();
        view.setBoardEnabled(false);
    }

    /**
     * Checks if the game has finished by determining if all treasures have been collected or if any player has no crew members.
     *
     * @return true if the game is finished, otherwise false
     * @author Tarek
     */
    public boolean isGameFinished() {
        // Kolla om någon spelare har inga besättningsmedlemmar kvar
        if (isGameOver()) {
            return true;
        }

        // Kolla om det finns några skatter kvar på brädet
        for (Map.Entry<String, Integer> entry : remainingTreasures.entrySet()) {
            if (entry.getValue() > 0) {
                return false;
            }
        }

        // Inga skatter kvar, spelet är över
        return true;
    }

    /**
     * Highlights all items of the specified type on the board.
     *
     * @param type the type of item (treasure or trap) to highlight
     * @author Mohammed
     */
    public void highlightTreasure(String type) {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                GameItem item = boardItems[i][j];
                if (item != null && item.getType().equals(type)) {
                    view.highlightButton(i, j);
                }
            }
        }
    }

    /**
     * Updates the leaderboard with the results from the current game and saves it to a file.
     *
     * @author Tarek
     */
    public void updateLeaderboard() {
        Player winner = player1.getPoints() > player2.getPoints() ? player1 : player2;

        // Läs in nuvarande topplista från filen
        List<Player> topPlayers = readLeaderboardFromFile();
        boolean foundWinner = false;
        // Gå igenom alla spelare i topplistan för att se om vinnaren redan finns där
        for (Player player : topPlayers) {
            if (player.getName().equals(winner.getName())) {
                if (winner.getPoints() > player.getPoints()) {
                    player.setPoints(winner.getPoints());
                }
                foundWinner = true;
                break;
            }
        }
        if (!foundWinner) {
            topPlayers.add(winner);
        }

        // Sortera topplistan och behåll de 10 bästa spelarna
        topPlayers.sort((p1, p2) -> Integer.compare(p2.getPoints(), p1.getPoints()));
        if (topPlayers.size() > 10) {
            topPlayers = topPlayers.subList(0, 10);
        }
        // Skriv den uppdaterade topplistan till filen
        writeLeaderboardToFile(topPlayers);
        // Uppdatera UI:t med den nya topplistan
        updateLeaderboardUI(topPlayers);
    }

    /**
     * Reads the leaderboard from a file.
     *
     * @return a list of players with their scores from the leaderboard
     * @author Mohammed
     */
    public List<Player> readLeaderboardFromFile() {
        List<Player> players = new ArrayList<>();
        File leaderboardFile = new File(LEADERBOARD_FILE);

        if (!leaderboardFile.exists()) {
            try {
                leaderboardFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
                return players;
            }
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(leaderboardFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts.length == 2) {
                    String name = parts[0];
                    int points = Integer.parseInt(parts[1].trim());
                    players.add(new Player(name, points));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return players;
    }

    /**
     * Writes the leaderboard to a file.
     *
     * @param players a list of players to be written to the file
     * @author Tarek
     */
    public void writeLeaderboardToFile(List<Player> players) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(LEADERBOARD_FILE))) {
            for (Player player : players) {
                writer.write(player.getName() + ": " + player.getPoints());
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Updates the leaderboard UI with the latest data from the file.
     *
     * @author Mohammed
     */
    public void updateLeaderboardFromFile() {
        List<Player> players = readLeaderboardFromFile();
        updateLeaderboardUI(players);
    }

    /**
     * Refreshes the leaderboard UI with the top players.
     *
     * @param topPlayers a list of top players to display
     * @author Tarek
     */
    public void updateLeaderboardUI(List<Player> topPlayers) {
        StringBuilder sb = new StringBuilder();
        sb.append("Top Players:\n");
        for (Player player : topPlayers) {
            sb.append(player.getName()).append(": ").append(player.getPoints()).append(" points\n");
        }
        leaderboard.setLeaderboardText(sb.toString());
    }
}
