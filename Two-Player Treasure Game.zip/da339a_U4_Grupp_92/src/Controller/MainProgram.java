package Controller;
public class MainProgram {

    /**
     * The main method serves as the entry point of the application.
     * It creates instances of the Controller, Gui, and Leaderboard classes,
     * sets up the Controller with references to the Gui and Leaderboard,
     * and then makes both the GUI and the Leaderboard visible to the user.
     *
     * @param args command-line arguments (not used in this application)
     */
    public static void main(String[] args) {
        Controller controller = new Controller();


    }
}
