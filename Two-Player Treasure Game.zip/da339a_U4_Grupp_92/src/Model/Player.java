package Model;

public class Player {
    private String name;
    private int points;
    private int crewMembers;  // Number of crew members


    private int boardType;

    public void setBoardType(int boardType) {
        this.boardType = boardType;
    }

    public int getBoardType() {
        return boardType;
    }


    /**
     * Initializes a Player object with a specified name and default values for points and crew members.
     * @author Tarek
     * @param name the name of the player
     */
    public Player(String name) {
        this.name = name;
        this.points = 0;  // Start with 0 points
        this.crewMembers = 3;  // Start with 3 crew members
    }

    /**
     * Initializes a Player object with a specified name and points, while setting the default number of crew members.
     * @author Tarek
     * @param name the name of the player
     * @param points the initial points of the player
     */
    public Player(String name, int points) {
        this.name = name;
        this.points = points;
        this.crewMembers = 3;  // Start with 3 crew members
    }

    /**
     * Returns the name of the player.
     * @author Tarek
     * @return the name of the player
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the points of the player.
     *
     * @return the points of the player
     */
    public int getPoints() {
        return points;
    }

    /**
     * Returns the number of crew members the player has.
     * @author Tarek
     * @return the number of crew members
     */
    public int getCrewMembers() {
        return crewMembers;
    }

    /**
     * Adds points to the player's total score.
     * @author Tarek
     * @param points the points to be added to the player's total
     */
    public void addPoints(int points) {
        this.points += points;
    }

    /**
     * Sets the player's points to a specific value.
     * @author Tarek
     * @param points the value to set the player's points to
     */
    public void setPoints(int points) {
        this.points = points;
    }

    /**
     * Adds a specified number of crew members to the player.
     * @author Tarek
     * @param count the number of crew members to add
     */
    public void addCrewMember(int count) {
        this.crewMembers += count;
    }

    /**
     * Checks if the player has no crew members left.
     *
     * @return true if the player has no crew members, false otherwise
     */
    public boolean hasNoCrew() {
        return this.crewMembers <= 0;
    }

    /**
     * Removes a specified number of crew members from the player.
     * @author Tarek
     * @param count the number of crew members to remove
     */
    public void removeCrewMember(int count) {
        this.crewMembers -= count;
    }
}
