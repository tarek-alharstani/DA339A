package Model;

import java.awt.Color;

/**
 * @author Tarek
 *
 * The MinorTreasure class represents a minor treasure in the game, categorized as a type of GameItem.
 * When a player encounters a minor treasure, they earn points.
 */
public class MinorTreasure extends GameItem {

    /**
     *  @author Tarek
     * Initializes a MinorTreasure object with the default type "Minor".
     */
    public MinorTreasure() {
        super("Minor");
    }

    /**
     * Increases the player's points when they land on a minor treasure.
     * @author Tarek
     * @param player the player whose points will be increased
     */
    @Override
    public void updatePoints(Player player) {
        player.addPoints(30);
    }

    /**
     * Retrieves the type of this game item.
     * @author Tarek
     * @return a string indicating the type of this game item
     */
    @Override
    public String getType() {
        return "Minor";
    }

    /**
     * Gets the color associated with this game item.
     * @author Tarek
     * @return the color representing this game item
     */
    @Override
    public Color getColor() {
        return Color.MAGENTA;
    }
}
