package Model;

import java.awt.Color;

/**
 * Represents a trap in the game, which is a specialized type of GameItem.
 * Landing on a trap causes the player to lose points.
 */

public class Trap extends GameItem {
    public Trap() {
        super("Trap");
    }
    /**
     *@author Mohammed
     */
    @Override
    public String getType() {
        return "Trap";
    }
    /**
     *@author Mohammed
     */
    @Override
    public Color getColor() {
        return Color.RED;
    }
    /**
     *@author Mohammed
     */
    @Override
    public void updatePoints(Player player) {
        player.removeCrewMember(1); // Förlorar en besättningsmedlem
    }


}
