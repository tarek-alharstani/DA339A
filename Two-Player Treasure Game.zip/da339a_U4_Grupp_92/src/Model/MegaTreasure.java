package Model;

import java.awt.Color;

/**
 *@author Mohammed
 *
 * The MegaTreasure class represents a mega treasure in the game, categorized as a type of GameItem.
 */
public class MegaTreasure extends GameItem {

    /**
     * @author Mohammed
     * Initializes a MegaTreasure object with the type "Mega".
     */
    public MegaTreasure() {
        super("Mega");
    }

    /**
     * Increases the player's points when they collect a mega treasure.
     *@author Mohammed
     * @param player the player whose points will be increased
     */
    @Override
    public void updatePoints(Player player) {
        player.addPoints(50);
    }

    /**
     * Retrieves the type of this game item.
     *@author Mohammed
     * @return a string indicating the type of this game item
     */
    @Override
    public String getType() {
        return"Mega";
    }

    /**
     * Gets the color associated with this game item.
     *@author Mohammed
     * @return the color representing this game item
     */
    @Override
    public Color getColor() {
        return Color.cyan;
    }
}
