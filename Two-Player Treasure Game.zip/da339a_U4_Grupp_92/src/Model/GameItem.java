package Model;

import java.awt.*;

/**
 * @author Mohamed
 *
 * The GameItem class represents an abstract game element that can be placed on the game board.
 * Each game element has a type, can modify a player's points, and has a color.
 */
public abstract class GameItem {
    private String type;

    /**
     * Constructs a GameItem object with the given type.
     *@author Mohamed
     * @param type the type of the game element
     */
    public GameItem(String type) {
        this.type = type;
    }

    /**
     * Retrieves the type of this game element.
     *@author Mohamed
     * @return a string that specifies the type of this game element
     */
    public abstract String getType();

    /**
     * Gets the color of the game element.
     *@author Mohamed
     * @return the color of the game element
     */
    public abstract Color getColor();

    /**
     * Adjusts the player's points according to the type of the game element.
     *@author Mohamed
     * @param player the player whose points will be adjusted
     */
    public abstract void updatePoints(Player player);
}
