package Model;

import java.awt.Color;  // Make sure to import Color class

/**
 * @author Tarek
 *
 * The Bonus class represents a special item in the game, classified as a type of GameItem.
 */
public class Bonus extends GameItem {

    /**
     * Initializes a Bonus object with the default type "Bonus".
     */
    public Bonus() {
        super("Bonus");  // Set the type of this GameItem as "Bonus"
    }

    /**
     * Returns the type of this game item.
     @author Tarek
     * @return a string indicating the type of this game item
     */
    @Override
    public String getType() {
        return "Bonus";  // Return the type of this GameItem
    }

    /**
     * Retrieves the color associated with this game item.
     *@author Tarek
     *
     * @return the color representing this game item
     */
    @Override
    public Color getColor() {
        return Color.blue;  // Use green as the color for the bonus item
    }

    /**
     * Updates the player's attributes when they find a bonus item.
     *
     * @param player the player who will receive the bonus
     * @author Tarek
     */
    @Override
    public void updatePoints(Player player) {
        player.addCrewMember(1);  // Adds an extra crew member to the player
    }

}

