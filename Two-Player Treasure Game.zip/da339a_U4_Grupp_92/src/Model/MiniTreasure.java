package Model;

import java.awt.*;

/**
 * @author Mohammed
 *
 * The MiniTreasure class represents a mini treasure in the game, categorized as a type of GameItem.
 */
public class MiniTreasure extends GameItem {

    /**
     * @author Mohammed
     * Initializes a MiniTreasure object with the default type "Mini".
     */
    public MiniTreasure() {
        super("Mini");
    }

    /**
     * Retrieves the type of this game item.
     *@author Mohammed
     * @return a string indicating the type of this game item
     */
    @Override
    public String getType() {
        return "Mini";
    }

    /**
     * Increases the player's points when they acquire a mini treasure.
     *@author Mohammed
     * @param player the player whose points will be increased
     */
    @Override
    public void updatePoints(Player player) {
        player.addPoints(5);
    }

    /**
     * Gets the color associated with this game item.
     *@author Mohammed
     * @return the color representing this game item
     */
    @Override
    public Color getColor() {
        return Color.DARK_GRAY;
    }
}
