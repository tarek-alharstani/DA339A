package Model;

import java.awt.Color;

/**
 * @author Tarek
 *
 * The MajorTreasure class represents a major treasure in the game, which is a specific type of GameItem.
 */
public class MajorTreasure extends GameItem {

    /**
     * Initializes a MajorTreasure object with the type "Major".
     */
    public MajorTreasure() {
        super("Major");
    }

    /**
     * Adds points to the player when they acquire a major treasure.
     *@author Tarek
     * @param player the player whose points will be increased
     */
    @Override
    public void updatePoints(Player player) {
        player.addPoints(10);
    }

    /**
     * Retrieves the type of this game item.
     *@author Tarek
     * @return a string indicating the type of this game item
     */
    @Override
    public String getType() {
        return "Major";
    }

    /**
     * Gets the color associated with this game item.
     *@author Tarek
     * @return the color representing this game item
     */
    @Override
    public Color getColor() {
        return new Color(205, 127, 50);
    }
}
