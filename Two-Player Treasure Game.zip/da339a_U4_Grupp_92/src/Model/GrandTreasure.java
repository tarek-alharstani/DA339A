package Model;

import java.awt.Color;

/**
 * @author Tarek
 *
 * The GrandTreasure class represents a major treasure in the game, classified as a type of GameItem.
 */
public class GrandTreasure extends GameItem {

    /**
     * Initializes a GrandTreasure object with the default type "Grand".
     */
    public GrandTreasure() {
        super("Grand");
    }

    /**
     * Increases the player's points when they find a grand treasure.
     *@author Tarek
     * @param player the player whose points will be increased
     */
    @Override
    public void updatePoints(Player player) {
        player.addPoints(40);
    }

    /**
     * Returns the type of this game item.
     *@author Tarek
     * @return a string indicating the type of this game item
     */
    @Override
    public String getType() {
        return "Grand";
    }

    /**
     * Retrieves the color associated with this game item.
     *@author Tarek
     * @return the color representing this game item
     */
    @Override
    public Color getColor() {
        return Color.YELLOW;
    }
}
